 <a href="{{CATEGORY_URL}}" class="taglink">
                        <div class="tag">
                            <div class="tagpic fn-left">
                                <img src="{{CATEGORY_THUMB}}" alt="{{CATEGORY_NAME}}">
                            </div>
                            <div class="taginfo fn-left">
                                <p class="pl">{{CATEGORY_NAME}}</p>
                                <p class="num">{{CATEGORY_NUMBER}} Games</p>
                            </div>
                        </div>
                    </a>