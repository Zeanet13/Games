<div class="post">
    <a href="{{CATEGORY_GAME_URL}}">
        <img src="{{CATEGORY_GAME_IMAGE}}" alt="{{CATEGORY_GAME_NAME}}">
        <p class="post-name">{{CATEGORY_GAME_NAME}}</p>
        <span class="featured_icon"></span>    </a>
</div>