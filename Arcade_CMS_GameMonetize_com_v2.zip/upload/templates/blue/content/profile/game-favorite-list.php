<li class="card-item">
	<figure class="card-game">
		<a class="g-media" data-href="{{PROFILE_GAME_FAVORITE_URL}}" href="{{PROFILE_GAME_FAVORITE_URL}}">
			<img src="{{PROFILE_GAME_FAVORITE_IMAGE}}" width="140px" height="96px">
			<span class="name ellipsis">{{PROFILE_GAME_FAVORITE_NAME}}</span>
		</a>
		<span class="cb-pro"></span>
	</figure>
</li>