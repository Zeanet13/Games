<div id="Pages" class="bgs">
    <div class="privacy-t">ABOUT US</div>
    <dl>
        <dd>
            <p>Welcome to GAMEFREE, an exciting new world for boys and girls game lovers.</p>
            <p>GAMEFREE has always tried to deliver freshness in the segment of baby games and special games designed for you.</p>
            <p>The lone aim of the website is to provide optimally educational games based on babies and feminism that give an enjoyable as well as a fruitful experience to our gamers.</p>
            <p>These games at GAMEFREE range for all age groups and have a vast spread of different games matching up to every gamers’ tastes.</p>
            <p>There is a lengthy list of games differed by categories such as baby care, babysitting , baby bathing and many other games for girls like spa, hair, fashion, cooking, dress up, cleaning, shopping, restaurant , makeup, makeover , nail, animal, decorating and coloring games.</p>
            <p>We further plan to expand this list by adding more exciting games for kids, new or soon to be moms and also for teens.</p>
            <p>So, now you can learn a lot and have fun while gaming at GAMEFREE.</p>
            <p>Parents can be extremely carefree as all our contents are vigilantly handpicked by our team of experts and thus are completely safe for kids.</p>
            <p>They are educational games that teach a lot to moms and children with absolutely no spending at all.</p>
            <p>Our ultimate aim is to provide fun time online for moms and their kids with varieties of different games of multiple levels.</p>
        </dd>
    </dl>
       <a href="https://gamemonetize.com" target="_blank" aria-label="GameMonetize.com CMS" style="display: block;text-align: center;padding-top: 20px;">
                <img src="https://api.gamemonetize.com/powered_by_gamemonetize.png" alt="GameMonetize.com CMS" style="width:290px;text-align: center;margin: 0 auto;">
            </a>
</div>