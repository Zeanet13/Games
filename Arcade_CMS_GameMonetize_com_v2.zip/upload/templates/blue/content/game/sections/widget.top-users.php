<ul class="s-list">
	{{WIDGET_SIDEBAR_TOP_USERS_LIST}}
</ul>