


  <li>
                <a href="{{RANDOM_GAME_URL}}">
                <div class="gameicon" style="background-image: url({{RANDOM_GAME_IMAGE}});background-size: cover;background-position-x: 50%;background-position-y: 50%;"></div>
                    <p class="post-name">{{RANDOM_GAME_NAME}}</p>
                </a>
            </li>