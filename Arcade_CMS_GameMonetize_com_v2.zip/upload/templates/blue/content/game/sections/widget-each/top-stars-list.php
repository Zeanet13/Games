  <li>
                <a href="{{WIDGET_TOPSTAR_URL}}"><img src="{{WIDGET_TOPSTAR_IMAGE}}">
                    <p class="post-name">{{WIDGET_TOPSTAR_NAME}}</p>
                </a>
            </li>