<ul style="margin-left:-3px;">
			{{WIDGET_SIDEBAR_TOP_STAR_LIST}}
</ul>