<?php 
/**
* GameMonetize.com CMS - An modern awesome arcade platform
* @copyright (c) All rights reserved
* @author GameMonetize.com
*
* @package GameMonetize CMS.com- Developers API
*
*/

/* Set up GameMonetize.com environment */
require_once( dirname( __FILE__ ) . '/gm-load.php');

if ( ! defined('API_PILOT') ) define('API_PILOT', true);

require_once( ABSPATH . 'assets/api/api-connector.php' );